import { useState } from 'react';
import { LoginSignup } from './components/LoginSignup';
import { EventsList } from './components/EventsList';
import { EventDetails } from './components/EventDetails';
import { Profile } from './components/Profile';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './components/Dashboard';

type Screen = 'login' | 'dashboard' | 'events' | 'study-groups' | 'messages' | 'event-details' | 'profile';

interface User {
  id: string;
  name: string;
  email: string;
}

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('login');
  const [user, setUser] = useState<User | null>(null);
  const [selectedEventId, setSelectedEventId] = useState<string>('');

  const handleLogin = (userData: User) => {
    setUser(userData);
    setCurrentScreen('dashboard');
  };

  const handleLogout = () => {
    setUser(null);
    setCurrentScreen('login');
  };

  const handleEventClick = (eventId: string) => {
    setSelectedEventId(eventId);
    setCurrentScreen('event-details');
  };

  const handleProfileClick = () => {
    setCurrentScreen('profile');
  };

  const handleScreenChange = (screen: Screen) => {
    setCurrentScreen(screen);
  };

  const handleBackToDashboard = () => {
    setCurrentScreen('dashboard');
  };

  // Login screen
  if (currentScreen === 'login') {
    return <LoginSignup onLogin={handleLogin} />;
  }

  // Main app layout with header and sidebar
  return (
    <div className="min-h-screen bg-background">
      <Header 
        user={user}
        onProfileClick={handleProfileClick}
        onLogout={handleLogout}
      />
      
      <div className="flex">
        <Sidebar 
          currentScreen={currentScreen as any}
          onScreenChange={handleScreenChange as any}
        />
        
        <main className="flex-1">
          {currentScreen === 'dashboard' && (
            <Dashboard 
              onEventClick={handleEventClick}
              onNavigate={handleScreenChange}
            />
          )}
          
          {currentScreen === 'events' && user && (
            <div className="p-6">
              <EventsList 
                onEventClick={handleEventClick}
                onProfileClick={handleProfileClick}
              />
            </div>
          )}
          
          {currentScreen === 'event-details' && (
            <div className="p-6">
              <EventDetails 
                onBack={handleBackToDashboard}
                eventId={selectedEventId}
              />
            </div>
          )}
          
          {currentScreen === 'profile' && user && (
            <div className="p-6">
              <Profile 
                user={user}
                onLogout={handleLogout}
              />
            </div>
          )}

          {currentScreen === 'study-groups' && (
            <div className="p-6">
              <div className="text-center py-12">
                <h2 className="text-2xl font-bold mb-4">Study Groups</h2>
                <p className="text-muted-foreground">Study groups feature coming soon!</p>
              </div>
            </div>
          )}

          {currentScreen === 'messages' && (
            <div className="p-6">
              <div className="text-center py-12">
                <h2 className="text-2xl font-bold mb-4">Messages</h2>
                <p className="text-muted-foreground">Messaging feature coming soon!</p>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}