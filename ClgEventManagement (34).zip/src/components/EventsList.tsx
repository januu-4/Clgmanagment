import { Calendar, MapPin, Users, Search, Plus } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface Event {
  id: string;
  title: string;
  date: string;
  time: string;
  location: string;
  attendees: number;
  category: string;
  image: string;
}

interface EventsListProps {
  onEventClick: (eventId: string) => void;
  onProfileClick: () => void;
}

export function EventsList({ onEventClick, onProfileClick }: EventsListProps) {
  const events: Event[] = [
    {
      id: '1',
      title: 'Machine Learning Study Group',
      date: 'Mar 15',
      time: '2:00 PM',
      location: 'Library Room 204',
      attendees: 12,
      category: 'Study Group',
      image: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?q=80&w=2971&auto=format&fit=crop'
    },
    {
      id: '2',
      title: 'React Workshop',
      date: 'Mar 16',
      time: '4:00 PM',
      location: 'Computer Lab A',
      attendees: 25,
      category: 'Workshop',
      image: 'https://images.unsplash.com/photo-1517180102446-f3ece451e9d8?q=80&w=2970&auto=format&fit=crop'
    },
    {
      id: '3',
      title: 'Campus Career Fair',
      date: 'Mar 18',
      time: '10:00 AM',
      location: 'Student Center',
      attendees: 150,
      category: 'Career',
      image: 'https://images.unsplash.com/photo-1559136555-9303baea8ebd?q=80&w=2970&auto=format&fit=crop'
    },
    {
      id: '4',
      title: 'Photography Club Meetup',
      date: 'Mar 20',
      time: '3:00 PM',
      location: 'Art Building',
      attendees: 8,
      category: 'Club',
      image: 'https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?q=80&w=2971&auto=format&fit=crop'
    }
  ];

  return (
    <div>
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold">Campus Events</h1>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          Create Event
        </Button>
      </div>

      {/* Content */}
      <div className="space-y-6">
        {/* Events Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {events.map((event) => (
            <Card 
              key={event.id} 
              className="cursor-pointer hover:shadow-lg transition-all hover:-translate-y-1"
              onClick={() => onEventClick(event.id)}
            >
              <CardContent className="p-0">
                <div className="aspect-video relative overflow-hidden rounded-t-lg">
                  <ImageWithFallback
                    src={event.image}
                    alt={event.title}
                    className="w-full h-full object-cover"
                  />
                  <Badge className="absolute top-3 left-3">
                    {event.category}
                  </Badge>
                </div>
                
                <div className="p-6">
                  <h3 className="text-xl font-semibold mb-3">{event.title}</h3>
                  
                  <div className="space-y-2 text-sm text-muted-foreground mb-4">
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4" />
                      <span>{event.date} • {event.time}</span>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <MapPin className="h-4 w-4" />
                      <span>{event.location}</span>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <Users className="h-4 w-4" />
                      <span>{event.attendees} attending</span>
                    </div>
                  </div>
                  
                  <Button className="w-full">View Details</Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}