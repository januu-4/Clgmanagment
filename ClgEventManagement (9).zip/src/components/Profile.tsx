import { Settings, Calendar, Users, BookOpen, MessageSquare, Edit, Bell, LogOut } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Separator } from './ui/separator';

interface ProfileProps {
  user: { id: string; name: string; email: string };
  onLogout: () => void;
}

export function Profile({ user, onLogout }: ProfileProps) {
  const stats = {
    eventsJoined: 8,
    studyGroups: 3,
    connections: 24
  };

  const recentActivity = [
    { type: 'joined', event: 'React Workshop', date: '2 days ago' },
    { type: 'created', event: 'Calculus Study Group', date: '1 week ago' },
    { type: 'completed', event: 'Python Bootcamp', date: '2 weeks ago' }
  ];

  const interests = ['Machine Learning', 'Web Development', 'Data Science', 'Mobile Apps'];

  return (
    <div className="max-w-4xl mx-auto">
      {/* Header */}
      <div className="bg-gradient-to-r from-indigo-500 to-purple-600 text-white rounded-lg mb-8">
        <div className="p-8">
          <div className="flex justify-between items-start mb-6">
            <h1 className="text-2xl font-bold">Profile</h1>
            <Button variant="ghost" size="sm" className="text-white hover:bg-white/20">
              <Settings className="h-4 w-4" />
            </Button>
          </div>
          
          <div className="flex items-center gap-6">
            <Avatar className="h-24 w-24 border-4 border-white/20">
              <AvatarImage src="" />
              <AvatarFallback className="text-xl bg-white/20 text-white">
                {user.name.split(' ').map(n => n[0]).join('')}
              </AvatarFallback>
            </Avatar>
            
            <div className="flex-1">
              <h2 className="text-2xl font-bold">{user.name}</h2>
              <p className="text-white/80 text-lg">{user.email}</p>
              <p className="text-white/80 mt-1">Computer Science • Senior</p>
            </div>
            
            <Button variant="ghost" size="sm" className="text-white hover:bg-white/20">
              <Edit className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column */}
        <div className="lg:col-span-1 space-y-6">
          {/* Stats Cards */}
          <div className="grid grid-cols-1 gap-4">
            <Card>
              <CardContent className="p-6 text-center">
                <div className="text-3xl font-bold text-indigo-600">{stats.eventsJoined}</div>
                <div className="text-muted-foreground">Events Joined</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6 text-center">
                <div className="text-3xl font-bold text-green-600">{stats.studyGroups}</div>
                <div className="text-muted-foreground">Study Groups</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6 text-center">
                <div className="text-3xl font-bold text-blue-600">{stats.connections}</div>
                <div className="text-muted-foreground">Connections</div>
              </CardContent>
            </Card>
          </div>

          {/* Interests */}
          <Card>
            <CardHeader>
              <CardTitle>Interests</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {interests.map((interest, index) => (
                  <Badge key={index} variant="secondary">{interest}</Badge>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Right Column */}
        <div className="lg:col-span-2 space-y-6">

          {/* Recent Activity */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {recentActivity.map((activity, index) => (
                <div key={index} className="flex items-center gap-4 p-4 border rounded-lg">
                  <div className="flex-shrink-0">
                    {activity.type === 'joined' && <Calendar className="h-6 w-6 text-blue-500" />}
                    {activity.type === 'created' && <Users className="h-6 w-6 text-green-500" />}
                    {activity.type === 'completed' && <BookOpen className="h-6 w-6 text-purple-500" />}
                  </div>
                  <div className="flex-1">
                    <p className="font-medium">{activity.event}</p>
                    <p className="text-sm text-muted-foreground">{activity.date}</p>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <Button variant="outline" className="justify-start">
                <Calendar className="h-4 w-4 mr-3" />
                My Events
              </Button>
              
              <Button variant="outline" className="justify-start">
                <Users className="h-4 w-4 mr-3" />
                Study Groups
              </Button>
              
              <Button variant="outline" className="justify-start">
                <MessageSquare className="h-4 w-4 mr-3" />
                Messages
              </Button>
              
              <Button variant="outline" className="justify-start">
                <Bell className="h-4 w-4 mr-3" />
                Notifications
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Logout */}
      <div className="mt-8 pt-6 border-t">
        <Button 
          variant="outline" 
          className="text-red-600 hover:text-red-700 hover:bg-red-50"
          onClick={onLogout}
        >
          <LogOut className="h-4 w-4 mr-2" />
          Sign Out
        </Button>
      </div>
    </div>
  );
}