import { ArrowLeft, Calendar, MapPin, Users, Clock, MessageCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface EventDetailsProps {
  onBack: () => void;
  eventId: string;
}

export function EventDetails({ onBack, eventId }: EventDetailsProps) {
  // Mock event data - in real app would fetch from backend
  const event = {
    id: eventId,
    title: 'Machine Learning Study Group',
    description: 'Join us for an intensive study session covering neural networks, deep learning fundamentals, and practical implementations. We\'ll work through problem sets and share notes from recent lectures.',
    date: '2024-03-15',
    time: '2:00 PM - 4:00 PM',
    location: 'Library Study Room 204',
    organizer: {
      name: 'Sarah Chen',
      avatar: '',
      year: 'Senior CS Major'
    },
    attendees: 12,
    maxAttendees: 15,
    category: 'Study Group',
    image: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?q=80&w=2971&auto=format&fit=crop',
    isJoined: false
  };

  const attendeeAvatars = [
    { name: 'John', avatar: '' },
    { name: 'Emma', avatar: '' },
    { name: 'Mike', avatar: '' },
    { name: 'Lisa', avatar: '' },
    { name: 'Tom', avatar: '' }
  ];

  return (
    <div className="max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <Button variant="ghost" size="sm" onClick={onBack}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <h1 className="text-2xl font-bold">Event Details</h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Main Content */}
        <div className="md:col-span-2 space-y-6">
          {/* Event Image */}
          <div className="aspect-video rounded-lg overflow-hidden">
            <ImageWithFallback
              src={event.image}
              alt={event.title}
              className="w-full h-full object-cover"
            />
          </div>
          {/* Title and Category */}
          <div className="space-y-3">
            <Badge variant="secondary" className="w-fit">
              {event.category}
            </Badge>
            <h2 className="text-3xl font-bold">{event.title}</h2>
          </div>

          {/* Description */}
          <div>
            <h3 className="text-xl font-semibold mb-3">About this event</h3>
            <p className="text-muted-foreground leading-relaxed">{event.description}</p>
          </div>

          {/* Attendees */}
          <div>
            <h3 className="text-xl font-semibold mb-4">Who's going ({event.attendees})</h3>
            <div className="flex gap-3">
              {attendeeAvatars.map((attendee, index) => (
                <Avatar key={index} className="h-12 w-12">
                  <AvatarImage src={attendee.avatar} />
                  <AvatarFallback>{attendee.name[0]}</AvatarFallback>
                </Avatar>
              ))}
              {event.attendees > 5 && (
                <div className="h-12 w-12 rounded-full bg-muted flex items-center justify-center font-medium">
                  +{event.attendees - 5}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Event Details Card */}
          <Card>
            <CardContent className="p-6 space-y-4">
              <div className="flex items-center gap-3 text-muted-foreground">
                <Calendar className="h-5 w-5" />
                <span>{event.date} • {event.time}</span>
              </div>
              
              <div className="flex items-center gap-3 text-muted-foreground">
                <MapPin className="h-5 w-5" />
                <span>{event.location}</span>
              </div>
              
              <div className="flex items-center gap-3 text-muted-foreground">
                <Users className="h-5 w-5" />
                <span>{event.attendees}/{event.maxAttendees} attendees</span>
              </div>
              
              <div className="flex items-center gap-3 text-muted-foreground">
                <Clock className="h-5 w-5" />
                <span>2 hours duration</span>
              </div>
            </CardContent>
          </Card>

          {/* Organizer */}
          <Card>
            <CardContent className="p-6">
              <h3 className="font-semibold mb-3">Organized by</h3>
              <div className="flex items-center gap-3">
                <Avatar className="h-12 w-12">
                  <AvatarImage src={event.organizer.avatar} />
                  <AvatarFallback>{event.organizer.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-medium">{event.organizer.name}</p>
                  <p className="text-sm text-muted-foreground">{event.organizer.year}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Action Buttons */}
          <div className="space-y-3">
            <Button className="w-full" size="lg">
              {event.isJoined ? 'Leave Event' : 'Join Event'}
            </Button>
            
            <Button variant="outline" className="w-full" size="lg">
              <MessageCircle className="h-4 w-4 mr-2" />
              Event Chat
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}