import { Calendar, Users, MessageSquare, BookOpen, TrendingUp, Home } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';

type Screen = 'dashboard' | 'events' | 'study-groups' | 'messages' | 'profile';

interface SidebarProps {
  currentScreen: Screen;
  onScreenChange: (screen: Screen) => void;
}

export function Sidebar({ currentScreen, onScreenChange }: SidebarProps) {
  const menuItems = [
    { id: 'dashboard' as Screen, label: 'Dashboard', icon: Home },
    { id: 'events' as Screen, label: 'Events', icon: Calendar, badge: '3' },
    { id: 'study-groups' as Screen, label: 'Study Groups', icon: Users },
    { id: 'messages' as Screen, label: 'Messages', icon: MessageSquare, badge: '2' },
  ];

  const quickStats = [
    { label: 'Events This Week', value: '8', color: 'text-blue-600' },
    { label: 'Study Groups', value: '3', color: 'text-green-600' },
    { label: 'New Messages', value: '12', color: 'text-purple-600' },
  ];

  return (
    <aside className="w-64 border-r bg-background h-[calc(100vh-73px)] sticky top-[73px]">
      <div className="p-6 space-y-6">
        {/* Navigation */}
        <nav className="space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentScreen === item.id;
            
            return (
              <Button
                key={item.id}
                variant={isActive ? "secondary" : "ghost"}
                className="w-full justify-start"
                onClick={() => onScreenChange(item.id)}
              >
                <Icon className="h-4 w-4 mr-3" />
                {item.label}
                {item.badge && (
                  <Badge variant="secondary" className="ml-auto text-xs">
                    {item.badge}
                  </Badge>
                )}
              </Button>
            );
          })}
        </nav>

        {/* Quick Stats */}
        <Card>
          <CardContent className="p-4">
            <h3 className="font-semibold mb-3">Quick Stats</h3>
            <div className="space-y-3">
              {quickStats.map((stat, index) => (
                <div key={index} className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">{stat.label}</span>
                  <span className={`font-semibold ${stat.color}`}>{stat.value}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Recent Activity */}
        <Card>
          <CardContent className="p-4">
            <h3 className="font-semibold mb-3">Recent Activity</h3>
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Calendar className="h-4 w-4 text-blue-500" />
                <div className="text-sm">
                  <p className="font-medium">Joined ML Workshop</p>
                  <p className="text-muted-foreground">2 hours ago</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Users className="h-4 w-4 text-green-500" />
                <div className="text-sm">
                  <p className="font-medium">Created Study Group</p>
                  <p className="text-muted-foreground">1 day ago</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <MessageSquare className="h-4 w-4 text-purple-500" />
                <div className="text-sm">
                  <p className="font-medium">New message in CS Club</p>
                  <p className="text-muted-foreground">2 days ago</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </aside>
  );
}