import { Calendar, Users, MessageSquare, BookOpen, Plus, ArrowRight } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface DashboardProps {
  onEventClick: (eventId: string) => void;
  onNavigate: (screen: string) => void;
}

export function Dashboard({ onEventClick, onNavigate }: DashboardProps) {
  const upcomingEvents = [
    {
      id: '1',
      title: 'Machine Learning Study Group',
      date: 'Today, 2:00 PM',
      location: 'Library Room 204',
      attendees: 12,
      image: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?q=80&w=400&auto=format&fit=crop'
    },
    {
      id: '2',
      title: 'React Workshop',
      date: 'Tomorrow, 4:00 PM',
      location: 'Computer Lab A',
      attendees: 25,
      image: 'https://images.unsplash.com/photo-1517180102446-f3ece451e9d8?q=80&w=400&auto=format&fit=crop'
    }
  ];

  const studyGroups = [
    { name: 'Advanced Algorithms', members: 8, nextSession: 'Wed 3:00 PM' },
    { name: 'Data Structures', members: 12, nextSession: 'Thu 1:00 PM' },
    { name: 'Web Development', members: 15, nextSession: 'Fri 2:00 PM' }
  ];

  const announcements = [
    { title: 'Career Fair Registration Open', time: '2 hours ago', urgent: true },
    { title: 'New Study Rooms Available in Library', time: '1 day ago', urgent: false },
    { title: 'Campus WiFi Maintenance Scheduled', time: '2 days ago', urgent: false }
  ];

  return (
    <div className="p-6 space-y-6">
      {/* Welcome Section */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Welcome back!</h1>
          <p className="text-muted-foreground mt-1">Here's what's happening on campus today</p>
        </div>
        <Button onClick={() => onNavigate('events')}>
          <Plus className="h-4 w-4 mr-2" />
          Create Event
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <Calendar className="h-5 w-5 text-blue-500" />
              <div>
                <p className="text-2xl font-bold">8</p>
                <p className="text-sm text-muted-foreground">Events This Week</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <Users className="h-5 w-5 text-green-500" />
              <div>
                <p className="text-2xl font-bold">3</p>
                <p className="text-sm text-muted-foreground">Study Groups</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <MessageSquare className="h-5 w-5 text-purple-500" />
              <div>
                <p className="text-2xl font-bold">12</p>
                <p className="text-sm text-muted-foreground">Unread Messages</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <BookOpen className="h-5 w-5 text-orange-500" />
              <div>
                <p className="text-2xl font-bold">24</p>
                <p className="text-sm text-muted-foreground">Resources Shared</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Upcoming Events */}
        <Card className="lg:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Upcoming Events</CardTitle>
            <Button variant="ghost" size="sm" onClick={() => onNavigate('events')}>
              View All <ArrowRight className="h-4 w-4 ml-1" />
            </Button>
          </CardHeader>
          <CardContent className="space-y-4">
            {upcomingEvents.map((event) => (
              <div 
                key={event.id}
                className="flex gap-4 p-4 rounded-lg border hover:bg-accent cursor-pointer transition-colors"
                onClick={() => onEventClick(event.id)}
              >
                <div className="w-20 h-20 rounded-lg overflow-hidden flex-shrink-0">
                  <ImageWithFallback
                    src={event.image}
                    alt={event.title}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold mb-1">{event.title}</h3>
                  <p className="text-sm text-muted-foreground mb-2">{event.date}</p>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <span>{event.location}</span>
                    <span>{event.attendees} attending</span>
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Study Groups */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Study Groups</CardTitle>
            <Button variant="ghost" size="sm">
              View All <ArrowRight className="h-4 w-4 ml-1" />
            </Button>
          </CardHeader>
          <CardContent className="space-y-4">
            {studyGroups.map((group, index) => (
              <div key={index} className="space-y-2">
                <div className="flex justify-between items-start">
                  <h4 className="font-medium">{group.name}</h4>
                  <Badge variant="secondary">{group.members}</Badge>
                </div>
                <p className="text-sm text-muted-foreground">Next: {group.nextSession}</p>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      {/* Announcements */}
      <Card>
        <CardHeader>
          <CardTitle>Campus Announcements</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {announcements.map((announcement, index) => (
              <div key={index} className="flex items-center justify-between p-3 rounded-lg border">
                <div className="flex items-center gap-3">
                  {announcement.urgent && (
                    <Badge variant="destructive">Urgent</Badge>
                  )}
                  <div>
                    <h4 className="font-medium">{announcement.title}</h4>
                    <p className="text-sm text-muted-foreground">{announcement.time}</p>
                  </div>
                </div>
                <Button variant="ghost" size="sm">
                  Read More
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}